
export const featuredMovie = {
  id: 1,
  title: "Dune: Part Two",
  backdropUrl: "https://images.unsplash.com/photo-1500673922987-e212871fec22",
  overview: "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe, he must prevent a terrible future only he can foresee.",
  rating: 8.7,
  year: 2024,
  genres: ["Sci-Fi", "Adventure", "Drama"],
  trailerUrl: "https://youtube.com/watch?v=dQw4w9WgXcQ",
  director: "Denis Villeneuve",
  cast: [
    { id: 1, name: "Timothée Chalamet", character: "Paul Atreides", profileUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=200&h=200&fit=crop" },
    { id: 2, name: "Zendaya", character: "Chani", profileUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=200&h=200&fit=crop" },
    { id: 3, name: "Rebecca Ferguson", character: "Lady Jessica", profileUrl: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=200&h=200&fit=crop" },
    { id: 4, name: "Josh Brolin", character: "Gurney Halleck", profileUrl: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=200&h=200&fit=crop" },
    { id: 5, name: "Javier Bardem", character: "Stilgar", profileUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=200&h=200&fit=crop" }
  ]
};

export const trendingMovies = [
  {
    id: 1,
    title: "Dune: Part Two",
    posterUrl: "https://images.unsplash.com/photo-1500673922987-e212871fec22?w=300&h=450&fit=crop",
    rating: 8.7,
    year: 2024,
    genres: ["Sci-Fi", "Adventure"]
  },
  {
    id: 2,
    title: "Oppenheimer",
    posterUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=300&h=450&fit=crop",
    rating: 8.5,
    year: 2023,
    genres: ["Drama", "Biography"]
  },
  {
    id: 3,
    title: "Poor Things",
    posterUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300&h=450&fit=crop",
    rating: 8.2,
    year: 2023,
    genres: ["Sci-Fi", "Romance"]
  },
  {
    id: 4,
    title: "The Holdovers",
    posterUrl: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=300&h=450&fit=crop",
    rating: 8.0,
    year: 2023,
    genres: ["Drama", "Comedy"]
  },
  {
    id: 5,
    title: "The Night House",
    posterUrl: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=300&h=450&fit=crop",
    rating: 6.8,
    year: 2023,
    genres: ["Horror", "Mystery"]
  },
  {
    id: 6,
    title: "The Winter Within",
    posterUrl: "https://images.unsplash.com/photo-1500673922987-e212871fec22?w=300&h=450&fit=crop",
    rating: 7.1,
    year: 2023,
    genres: ["Drama", "Mystery"]
  }
];

export const newReleases = [
  {
    id: 7,
    title: "Civil War",
    posterUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300&h=450&fit=crop",
    rating: 8.1,
    year: 2024,
    genres: ["Action", "Drama"]
  },
  {
    id: 8,
    title: "The First Omen",
    posterUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=300&h=450&fit=crop",
    rating: 7.5,
    year: 2024,
    genres: ["Horror", "Thriller"]
  },
  {
    id: 9,
    title: "The Fall Guy",
    posterUrl: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=300&h=450&fit=crop",
    rating: 7.8,
    year: 2024,
    genres: ["Action", "Comedy"]
  },
  {
    id: 10,
    title: "Kingdom of the Planet of the Apes",
    posterUrl: "https://images.unsplash.com/photo-1500673922987-e212871fec22?w=300&h=450&fit=crop",
    rating: 7.9,
    year: 2024,
    genres: ["Sci-Fi", "Action"]
  },
  {
    id: 11,
    title: "Furiosa",
    posterUrl: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=300&h=450&fit=crop",
    rating: 8.3,
    year: 2024,
    genres: ["Action", "Adventure"]
  }
];

export const recommendedMovies = [
  {
    id: 12,
    title: "The Batman",
    posterUrl: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=300&h=450&fit=crop",
    rating: 7.8,
    year: 2022,
    genres: ["Action", "Crime"]
  },
  {
    id: 13,
    title: "Everything Everywhere All at Once",
    posterUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300&h=450&fit=crop",
    rating: 8.9,
    year: 2022,
    genres: ["Action", "Sci-Fi"]
  },
  {
    id: 14,
    title: "Top Gun: Maverick",
    posterUrl: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=300&h=450&fit=crop",
    rating: 8.3,
    year: 2022,
    genres: ["Action", "Drama"]
  },
  {
    id: 15,
    title: "Black Panther: Wakanda Forever",
    posterUrl: "https://images.unsplash.com/photo-1500673922987-e212871fec22?w=300&h=450&fit=crop",
    rating: 7.2,
    year: 2022,
    genres: ["Action", "Adventure"]
  }
];

export const reviewsMock = [
  {
    id: 1,
    user: {
      name: "Alex Johnson",
      avatar: "https://images.unsplash.com/photo-1500673922987-e212871fec22?w=100&h=100&fit=crop"
    },
    rating: 5,
    date: "Apr 15, 2024",
    content: "This movie completely blew me away! The visuals were stunning and the story kept me on the edge of my seat from beginning to end. Definitely a must-watch for any sci-fi fan.",
    helpfulCount: 24
  },
  {
    id: 2,
    user: {
      name: "Sam Wilson",
      avatar: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=100&h=100&fit=crop"
    },
    rating: 4,
    date: "Apr 10, 2024",
    content: "I really enjoyed this film, though I felt the middle section dragged a bit. The performances were outstanding and the cinematography was breathtaking. Would recommend to friends!",
    helpfulCount: 18
  },
  {
    id: 3,
    user: {
      name: "Taylor Reed",
      avatar: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=100&h=100&fit=crop"
    },
    rating: 3,
    date: "Apr 5, 2024",
    content: "It was good, but not great. I expected more from the character development, though the action sequences were well choreographed. Still worth watching if you're a fan of the genre.",
    helpfulCount: 7
  }
];
