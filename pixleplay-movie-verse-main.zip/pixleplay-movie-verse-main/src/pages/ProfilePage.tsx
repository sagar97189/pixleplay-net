
import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import MovieCarousel from '@/components/MovieCarousel';
import { recommendedMovies, trendingMovies } from '@/data/mockData';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const avatarOptions = [
  'https://images.unsplash.com/photo-1500673922987-e212871fec22?w=100&h=100&fit=crop',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=100&h=100&fit=crop',
  'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=100&h=100&fit=crop',
  'https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=100&h=100&fit=crop',
  'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=100&h=100&fit=crop',
];

const ProfilePage = () => {
  const [userName, setUserName] = useState('Jane Doe');
  const [selectedAvatar, setSelectedAvatar] = useState(avatarOptions[0]);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-8">
            <div className="relative">
              <Avatar className="w-24 h-24 border-2 border-primary">
                <AvatarImage src={selectedAvatar} alt={userName} />
                <AvatarFallback>{userName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              
              {isEditingProfile && (
                <div className="absolute -bottom-2 -right-2">
                  <Button 
                    size="sm" 
                    variant="secondary" 
                    className="rounded-full h-8 w-8 p-0"
                    onClick={() => document.getElementById('avatar-selector')?.classList.toggle('hidden')}
                  >
                    Edit
                  </Button>
                  
                  <div 
                    id="avatar-selector" 
                    className="absolute right-0 bottom-10 bg-background border border-border p-2 rounded-lg hidden animate-fade-in"
                  >
                    <div className="flex gap-2">
                      {avatarOptions.map((avatar) => (
                        <button 
                          key={avatar} 
                          className={`rounded-full overflow-hidden h-10 w-10 border-2 ${avatar === selectedAvatar ? 'border-primary' : 'border-transparent'}`}
                          onClick={() => setSelectedAvatar(avatar)}
                        >
                          <img src={avatar} alt="Avatar option" className="h-full w-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex flex-col md:flex-row justify-between items-center mb-4">
                {isEditingProfile ? (
                  <Input 
                    value={userName} 
                    onChange={(e) => setUserName(e.target.value)} 
                    className="max-w-xs bg-secondary/30"
                  />
                ) : (
                  <h1 className="text-3xl font-bold">{userName}</h1>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={() => setIsEditingProfile(!isEditingProfile)}
                  className="mt-2 md:mt-0"
                >
                  {isEditingProfile ? 'Save Profile' : 'Edit Profile'}
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">42</div>
                  <div className="text-sm text-muted-foreground">Favorites</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">128</div>
                  <div className="text-sm text-muted-foreground">Watched</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">17</div>
                  <div className="text-sm text-muted-foreground">Reviews</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Profile Content */}
          <Tabs defaultValue="watchlist" className="w-full">
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="watchlist">My Watchlist</TabsTrigger>
              <TabsTrigger value="watched">Watched</TabsTrigger>
              <TabsTrigger value="reviews">My Reviews</TabsTrigger>
            </TabsList>
            
            <TabsContent value="watchlist">
              <MovieCarousel 
                title="My Watchlist" 
                movies={recommendedMovies} 
              />
              
              <div className="mt-8">
                <h2 className="text-xl font-semibold mb-4">Recently Added</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {trendingMovies.map((movie) => (
                    <div key={movie.id} className="animate-fade-in">
                      <img 
                        src={movie.posterUrl} 
                        alt={movie.title} 
                        className="rounded-lg w-full aspect-[2/3] object-cover movie-card"
                      />
                      <h3 className="mt-2 text-sm font-medium truncate">{movie.title}</h3>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="watched">
              <div className="text-center py-12">
                <h3 className="text-lg mb-2">Your watch history will appear here</h3>
                <p className="text-muted-foreground">Start watching movies to build your history</p>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews">
              <div className="text-center py-12">
                <h3 className="text-lg mb-2">Your reviews will appear here</h3>
                <p className="text-muted-foreground">Start rating movies to see your reviews</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default ProfilePage;
