
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Star, Share } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CastList from '@/components/CastList';
import MovieCarousel from '@/components/MovieCarousel';
import ReviewSection from '@/components/ReviewSection';
import { Button } from '@/components/ui/button';
import { featuredMovie, trendingMovies, reviewsMock } from '@/data/mockData';

const MovieDetail = () => {
  const { id } = useParams<{ id: string }>();
  
  // In a real app, we would fetch the movie details based on id
  // For now, we'll use the featured movie as a placeholder
  const movie = featuredMovie;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero/Banner Section */}
      <div className="relative w-full h-[50vh] min-h-[400px] pt-16">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${movie.backdropUrl})` }}
        >
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 -mt-32 relative z-10">
        <Link to="/" className="inline-flex items-center text-sm mb-6 hover:text-primary transition-colors">
          <ArrowLeft className="h-4 w-4 mr-1" /> Back to browse
        </Link>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left column - Poster */}
          <div className="md:col-span-1">
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img 
                src={movie.backdropUrl.replace('?', '?w=400&h=600&fit=crop')} 
                alt={movie.title} 
                className="w-full h-auto object-cover"
              />
            </div>
            
            <div className="flex justify-between mt-4">
              <Button variant="default" className="w-full" asChild>
                <a href={movie.trailerUrl} target="_blank" rel="noopener noreferrer">
                  <Play className="mr-2 h-4 w-4" /> Watch Trailer
                </a>
              </Button>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button variant="outline" className="w-full">
                <Share className="mr-2 h-4 w-4" /> Share
              </Button>
            </div>
          </div>
          
          {/* Right column - Details */}
          <div className="md:col-span-2">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{movie.title}</h1>
            
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                <span className="font-medium">{movie.rating.toFixed(1)}</span>
              </div>
              <span className="text-gray-400">{movie.year}</span>
              <div className="flex flex-wrap">
                {movie.genres.map((genre) => (
                  <span key={genre} className="genre-pill">
                    {genre}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-2">Overview</h2>
              <p className="text-gray-300">{movie.overview}</p>
            </div>
            
            <div className="mb-6">
              <div><span className="font-semibold">Director:</span> <span className="text-gray-300">{movie.director}</span></div>
            </div>
            
            {/* Cast Section */}
            <CastList cast={movie.cast} />
            
            {/* Reviews Section */}
            <ReviewSection reviews={reviewsMock} />
          </div>
        </div>
        
        {/* Related Movies */}
        <div className="mt-12">
          <MovieCarousel 
            title="You May Also Like" 
            movies={trendingMovies.filter(m => m.id !== Number(id))} 
          />
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default MovieDetail;
