
import React from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import MovieCarousel from '@/components/MovieCarousel';
import Footer from '@/components/Footer';
import { featuredMovie, trendingMovies, newReleases, recommendedMovies } from '@/data/mockData';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-16">
        <Hero movie={featuredMovie} />
      </section>
      
      {/* Content Sections */}
      <div className="container mx-auto px-4 py-8">
        {/* Trending Movies */}
        <MovieCarousel title="Trending Now" movies={trendingMovies} />
        
        {/* New Releases */}
        <MovieCarousel title="New Releases" movies={newReleases} />
        
        {/* Top Picks For You */}
        <MovieCarousel title="Top Picks For You" movies={recommendedMovies} />
        
        {/* Hidden Gems */}
        <MovieCarousel 
          title="Hidden Gems" 
          movies={[...recommendedMovies].sort(() => Math.random() - 0.5)} 
          size="small"
        />
      </div>
      
      <Footer />
    </div>
  );
};

export default Index;
