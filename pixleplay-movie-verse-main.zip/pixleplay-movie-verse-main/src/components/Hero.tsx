
import React from 'react';
import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroProps {
  movie: {
    id: number;
    title: string;
    backdropUrl: string;
    overview: string;
    rating: number;
    year: number;
    genres: string[];
  };
}

const Hero = ({ movie }: HeroProps) => {
  return (
    <div className="relative w-full h-[70vh] min-h-[500px] overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${movie.backdropUrl})` }}
      >
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
      </div>
      
      <div className="relative container mx-auto px-4 h-full flex items-end pb-16">
        <div className="max-w-2xl animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{movie.title}</h1>
          <div className="flex items-center space-x-4 mb-4">
            <span className="px-2 py-1 bg-primary/90 rounded text-sm">{movie.rating.toFixed(1)}</span>
            <span>{movie.year}</span>
            <div className="flex space-x-2">
              {movie.genres.slice(0, 3).map((genre) => (
                <span key={genre} className="genre-pill">
                  {genre}
                </span>
              ))}
            </div>
          </div>
          <p className="text-gray-300 mb-6 line-clamp-3">{movie.overview}</p>
          <div className="flex space-x-4">
            <Button asChild>
              <Link to={`/movie/${movie.id}`}>
                <Play className="mr-2 h-4 w-4" /> Watch Trailer
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to={`/movie/${movie.id}`}>More Info</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
