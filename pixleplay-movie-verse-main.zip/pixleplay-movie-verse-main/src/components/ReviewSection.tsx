
import React, { useState } from 'react';
import { Star, ThumbsUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface Review {
  id: number;
  user: {
    name: string;
    avatar: string;
  };
  rating: number;
  date: string;
  content: string;
  helpfulCount: number;
}

interface ReviewSectionProps {
  reviews: Review[];
}

const ReviewSection = ({ reviews }: ReviewSectionProps) => {
  const [newReview, setNewReview] = useState('');
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we would submit the review to an API
    console.log('Submitting review:', { rating, content: newReview });
    // Reset form
    setNewReview('');
    setRating(0);
  };

  return (
    <div className="py-6">
      <h2 className="text-xl font-semibold mb-4">User Reviews</h2>

      {/* Write a review */}
      <div className="bg-secondary/20 p-4 rounded-lg mb-8">
        <h3 className="text-lg font-medium mb-2">Write a Review</h3>
        <form onSubmit={handleReviewSubmit}>
          <div className="flex items-center mb-4">
            <div className="mr-2">Your rating:</div>
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="focus:outline-none"
                >
                  <Star
                    className={`h-5 w-5 ${
                      star <= (hoveredRating || rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <Textarea
            value={newReview}
            onChange={(e) => setNewReview(e.target.value)}
            placeholder="Share your thoughts about this movie..."
            className="mb-4 bg-secondary/30"
            rows={4}
          />
          <Button type="submit" disabled={!rating || !newReview.trim()}>
            Submit Review
          </Button>
        </form>
      </div>

      {/* Review list */}
      <div className="space-y-6">
        {reviews.length > 0 ? (
          reviews.map((review) => (
            <div key={review.id} className="border-b border-gray-700 pb-6 last:border-0 animate-fade-in">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <Avatar className="h-8 w-8 mr-3">
                    <AvatarImage src={review.user.avatar} alt={review.user.name} />
                    <AvatarFallback>
                      {review.user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{review.user.name}</div>
                    <div className="flex items-center">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-gray-400 ml-2">{review.date}</span>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-300 mb-3">{review.content}</p>
              <div className="flex items-center text-xs text-gray-400">
                <Button variant="ghost" size="sm" className="flex items-center">
                  <ThumbsUp className="h-3 w-3 mr-1" />
                  Helpful ({review.helpfulCount})
                </Button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-400 italic">No reviews yet. Be the first to share your thoughts!</p>
        )}
      </div>
    </div>
  );
};

export default ReviewSection;
