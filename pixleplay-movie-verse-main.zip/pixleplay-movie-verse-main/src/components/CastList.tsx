
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface CastMember {
  id: number;
  name: string;
  character: string;
  profileUrl: string;
}

interface CastListProps {
  cast: CastMember[];
}

const CastList = ({ cast }: CastListProps) => {
  return (
    <div className="py-6">
      <h2 className="text-xl font-semibold mb-4">Cast</h2>
      <div className="flex space-x-4 overflow-x-auto pb-4 -mx-4 px-4">
        {cast.map((person) => (
          <div key={person.id} className="flex-shrink-0 w-28">
            <div className="flex flex-col items-center text-center">
              <Avatar className="w-20 h-20">
                <AvatarImage src={person.profileUrl} alt={person.name} />
                <AvatarFallback>
                  {person.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="mt-2">
                <p className="font-medium text-sm line-clamp-1">{person.name}</p>
                <p className="text-xs text-muted-foreground line-clamp-1">{person.character}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CastList;
