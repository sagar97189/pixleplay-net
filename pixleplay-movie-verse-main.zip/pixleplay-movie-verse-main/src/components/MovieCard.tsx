
import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';

interface MovieCardProps {
  id: number;
  title: string;
  posterUrl: string;
  rating: number;
  year: number;
  genres: string[];
  size?: 'small' | 'medium' | 'large';
}

const MovieCard = ({ id, title, posterUrl, rating, year, genres, size = 'medium' }: MovieCardProps) => {
  const sizeClasses = {
    small: 'w-36 h-52',
    medium: 'w-48 h-72', 
    large: 'w-64 h-96'
  };

  return (
    <Link to={`/movie/${id}`}>
      <div className={`movie-card group ${sizeClasses[size]} animate-fade-in`}>
        <img 
          src={posterUrl} 
          alt={title} 
          className="w-full h-full object-cover rounded-lg"
          loading="lazy"
        />
        <div className="movie-card-overlay"></div>
        <div className="movie-card-content">
          <h3 className="font-bold text-white truncate">{title}</h3>
          <div className="flex items-center text-xs text-white/70 mt-1">
            <span>{year}</span>
            <span className="mx-1">•</span>
            <div className="flex items-center">
              <Star className="h-3 w-3 text-yellow-400 mr-0.5" />
              <span>{rating.toFixed(1)}</span>
            </div>
          </div>
          {size !== 'small' && (
            <div className="mt-2 flex flex-wrap -mx-1">
              {genres.slice(0, 2).map((genre) => (
                <span key={genre} className="genre-pill">
                  {genre}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};

export default MovieCard;
